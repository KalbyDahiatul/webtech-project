<!DOCTYPE html>
<html>
<?php
include "header.php";
if (!isset($_SESSION['flag']) || $_SESSION['flag'] == '') {
    header("location:login.php");
}

$data = file_get_contents("payment_data.json");
$data = json_decode($data, true);

$d_id = $_GET['id'];

?>

<head>
    <meta charset="utf-8">
    <title>Docter Detail</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
    <div>
        <div class="row">
            <div class="col-sm-2">
                <nav class="nav flex-column nav-pills nav-fill">
                    <a class="nav-link" href="dashboard.php">Dashboard</a>
                    <a class="nav-link" href="doctors.php">Doctor List</a>
                    <a class="nav-link" href="patients.php">Patient List</a>
                    <a class="nav-link" href="payment.php">Payments</a>
                    
                </nav>
            </div>
            <div class="col-sm-8">
            <p class="font-weight-normal">Transaction no: <?php echo $data[$d_id]["id"]; ?></p>
            <p class="font-weight-normal">Name: <?php echo $data[$d_id]["name"]; ?></p>
            <p class="font-weight-normal">Amount: <?php echo $data[$d_id]["amount"]; ?></p>
            <p class="font-weight-normal">Payment Status: <?php echo $data[$d_id]["status"]; ?></p>
            <a href="updatepayment.php?id=<?php echo $data[$d_id]["id"];?>&status=<?php echo "Paid";?>"class="btn btn-success btn-lg active" role="button" aria-pressed="true">Update Status to Paid</a>
            <a href="updatepayment.php?id=<?php echo $data[$d_id]["id"];?>&status=<?php echo "Not paid";?>"class="btn btn-warning btn-lg active" role="button" aria-pressed="true">Update Status to Not Paid</a>
            </div>

            <?php
            echo $data[$d_id]["name"];
            ?>

        </div>
    </div>
    </div>




</body>

</html>