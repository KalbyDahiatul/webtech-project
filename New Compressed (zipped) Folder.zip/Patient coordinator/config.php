<?php
session_start();
$dbHost = 'localhost';
$dbname = 'health';
$dbUsername = 'root';
$dbPassword = 'admin';
$dbc = mysqli_connect($dbHost,$dbUsername,$dbPassword,$dbname);

?>