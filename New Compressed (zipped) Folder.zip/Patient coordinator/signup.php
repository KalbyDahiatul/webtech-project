<!DOCTYPE html>
<html>

<head>
	<meta charset="utf-8">
	<title>Signup</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
	<?php
	session_start();
	$message = '';
	$name_err = $email_err = $uname_err = $pass_err = $cpass_err = "";
	if ($_SERVER["REQUEST_METHOD"] == "POST") {
		if (empty($_POST["uname"])) {
			$name_err = "Name is required";
		} 

		if (empty($_POST["email"])) {
			$email_err = "Email is required";
		} 
		
		if (empty($_POST["usname"])) {
			$uname_err = "Username is required";
		}
		if (empty($_POST["pass"])) {
			$pass_err = "Password is required";
		} 
		
		if (empty($_POST["cpass"])) {
			$cpass_err = "Confirm password filed cannot be empty";
		} else {
			if ($_POST["cpass"] != $_POST["pass"])
				$cpass_err = "Mismatched password!!!";
		}
		
	if (isset($_POST['submit'])) {
		
		if ($name_err == "" && $email_err == "" && $uname_err == "" && $pass_err == "" && $cpass_err == "") { 
			
				if (file_exists('data1.json')) {

					$current_data = file_get_contents('data1.json');
					$array_data = json_decode($current_data, true);
					$extra = array(
						'name' =>     $_POST['uname'],
						'e-mail' =>     $_POST["email"],
						'username' =>     $_POST["usname"],
						'password' =>      $_POST["pass"]
					);
					$array_data[] = $extra;
					$final_data = json_encode($array_data);
					if (file_put_contents('data1.json', $final_data)) {
						$message = "File Appended Success fully";
						header("location: login.php");
					}
				} else {
					$error = 'JSON File not exits';
				}
			
		}
	}
}
	

	

		
	?>
	<nav class="navbar navbar-dark bg-primary">
  <div class="container-fluid">
    <span class="navbar-text text-white bg-primary ">
      Patient Coordinate Signup
    </span>
  </div>
  <form class="container-fluid justify-content-end">
    <a href="login.php" class="btn btn-primary btn-lg active" role="button" aria-pressed="true">Login</a>&nbsp;
	<a href="signup.php" class="btn btn-success btn-lg active" role="button" aria-pressed="true">Signup</a>
  </form>
</nav>
  

	<div class="container">
		<div class="row">
			<div class="col-sm-4">
			</div>
			<div class="col-sm-4">
				<form method="post" action="">
					<div class="mb-3">
						<label for="Email1" class="form-label">Email address</label>
						<input type="email" class="form-control" id="Email1" name="email" aria-describedby="emailHelp">
						<span class="error"><?php echo $email_err; ?></span>

					</div>
					<div class="mb-3">
						<label for="Name1" class="form-label">Name</label>
						<input type="text" class="form-control" id="Name1" name="uname" aria-describedby="emailHelp">
						<span class="error"><?php echo $name_err; ?></span>
					</div>
					<div class="mb-3">
						<label for="UName1" class="form-label">User Name</label>
						<input type="text" class="form-control" id="UName1" name="usname" aria-describedby="emailHelp">
						<span class="error"><?php echo $uname_err; ?></span>
					</div>
					<div class="mb-3">
						<label for="Password1" class="form-label">Password</label>
						<input type="password" class="form-control" name="pass" id="Password1">
						<span class="error"><?php echo $pass_err; ?></span>
					</div>
					<div class="mb-3">
						<label for="cPassword1" class="form-label">Confirm Password</label>
						<input type="password" class="form-control" name="cpass" id="cPassword1">
						<span class="error"><?php echo $cpass_err; ?></span>
					</div>
					<button type="submit" class="btn btn-primary" name="submit" value="Submit">Submit</button>
					<button type="reset" class="btn btn-danger" name="reset" value="Reset">Reset</button>

				</form>
			</div>
			<div class="col-sm-4">

			</div>
		</div>
	</div>
	
</body>

<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js"></script>

</html>