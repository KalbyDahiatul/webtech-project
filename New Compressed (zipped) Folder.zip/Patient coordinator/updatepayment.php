<?php
include "header.php";
if (!isset($_SESSION['flag']) || $_SESSION['flag'] == '') {
    header("location:login.php");
}

$data = file_get_contents("payment_data.json");
$data = json_decode($data, true);

$d_id = $_GET['id'];
$d_status = $_GET['status'];
echo $d_status;

$data[$d_id]["status"] = $d_status;
$final_data = json_encode($data);
if (file_put_contents('payment_data.json', $final_data)) {
    $message = "File Appended Success fully";
    header("location:paymentdetails.php?id=".$d_id);
}
